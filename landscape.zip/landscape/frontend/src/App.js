import React, { useState, useEffect } from "react";
import "./styles.css";

function App() {
  const [articles, setArticles] = useState([]);
  const [query, setQuery] = useState("Articles");
  const [modalContent, setModalContent] = useState(null);
  const [searchInput, setSearchInput] = useState("");

  useEffect(() => {
    fetch(`http://localhost:5000/api/news?q=${query}`)
      .then((res) => res.json())
      .then((data) => setArticles(data.articles))
      .catch((err) => console.error(err));
  }, [query]);

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchInput.trim()) {
      setQuery(searchInput);
    }
  };

  return (
    <div className="App">
      <header>
        <h1>📰 News Landscape</h1>

        <form onSubmit={handleSearch} className="search-bar">
          <input
            type="text"
            placeholder="Search news..."
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
          />
          <button type="submit">Search</button>
        </form>

        <div className="nav-tabs">
          {[
            "Tamil Nadu",
            "Flood",
            "School",
            "Weather",
            "Politics",
            "WAR",
            "TVK",
          ].map((tab) => (
            <div
              key={tab}
              className={`nav-tab ${query === tab ? "active" : ""}`}
              onClick={() => setQuery(tab)}
            >
              {tab}
            </div>
          ))}
        </div>
      </header>

      <div className="news-grid">
        {articles.map((article, index) => (
          <div key={index} className="news-card">
            <img src={article.image} alt="news" />
            <h3>{article.title}</h3>
            <p>{article.description}</p>
            <small>
              {article.source} • {new Date(article.publishedAt).toLocaleDateString()}
            </small>
            <button onClick={() => setModalContent(article)}>Read More</button>
          </div>
        ))}
      </div>

      {modalContent && (
        <div className="modal-overlay" onClick={() => setModalContent(null)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <h2>{modalContent.title}</h2>
            <img src={modalContent.image} alt="modal-news" />
            <p>{modalContent.description}</p>
            <button onClick={() => setModalContent(null)}>Close</button>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
