import React from 'react';
import '../styles.css';

function NewsCard({ article, onReadMore }) {
    return (
        <div className="news-card" onClick={() => onReadMore(article)}>
            <img src={article.image} alt="news" />
            <h3>{article.title}</h3>
            <p>{article.description}</p>
            <button className="read-more-btn">Read More</button>
        </div>
    );
}

export default NewsCard;
