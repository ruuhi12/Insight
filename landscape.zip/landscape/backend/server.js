const express = require('express');
const axios = require('axios');
const cors = require('cors');
const app = express();
const PORT = 5000;

const GNEWS_API_KEY = 'd7e5804605638175508d1ada027aec45';

app.use(cors());

app.get('/api/news', async (req, res) => {
    const query = req.query.q || 'technology';

    try {
        const response = await axios.get('https://gnews.io/api/v4/search', {
            params: {
                q: query,
                token: GNEWS_API_KEY,
                lang: 'en',
                max: 10
            }
        });

        const articles = response.data.articles.map(article => ({
            title: article.title,
            description: article.description,
            url: article.url,
            image: article.image,
            publishedAt: article.publishedAt,
            source: article.source.name
        }));

        res.json({ articles });
    } catch (err) {
        res.status(500).json({ error: 'Failed to fetch news' });
    }
});

app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
